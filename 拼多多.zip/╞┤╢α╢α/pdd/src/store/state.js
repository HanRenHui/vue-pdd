export default {
  imgUrl: [],
  CarouImg: [],
  NavDate: {},
  HomeGoodsList: [],
  ReqList: [],
  // 搜索列表
  SearchList: [],
  User: {},
  // 人造购物车数据
  cartGoods: [
    {
      "goods_id": 1031855,
      "goods_name": "【甜曲】紫米面包550g/2200g黑米夹心奶酪蛋糕减脂早餐营养代餐",
      "thumb_url": "http://t00img.yangkeduo.com/goods/images/2018-08-30/1093ac9bfaa77304a8c3f25d4bfcb743.jpeg",
      "price": 990,
      "buy_count": 2,
      "is_pay": 0,
      "checked": false
    },
    {
      "goods_id": 101758846,
      "goods_name": "【冰薇儿】高腰弹力大码胖mm牛仔裤女长裤春秋季松紧腰九分显瘦",
      "thumb_url": "http://t00img.yangkeduo.com/goods/images/2018-08-07/8af1aade86ac71055c6de10f9c089ce9.jpeg",
      "price": 3960,
      "buy_count": 1,
      "is_pay": 0,
      "checked": false

    },
    {
      "goods_id": 1050064439,
      "goods_name": "兰月星本色卷纸35卷24卷12卷精品装纸巾厕纸卫生纸妇婴可用纸",
      "thumb_url": "http://t00img.yangkeduo.com/t03img/images/2018-06-04/bd0fd6a1a83ab5c2aab737c270d37844.jpeg",
      "price": 990,
      "buy_count": 2,
      "is_pay": 0,
      "checked": false

    }
  ]
}