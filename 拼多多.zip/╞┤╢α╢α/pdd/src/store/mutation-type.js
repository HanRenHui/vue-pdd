const TAB_DATA = 'reqTabContent';
const CAROU_IMG = 'reqCarouImg';
const HotNav = 'reqHotNav';
const GOODLSIT = 'requireGoodsList'
const RECLIST = 'reqRecList';
const REWRITE = 'rewriteuserinfo';
const AUTOLOGIN = 'autologin';
const EDIT = 'editlogin';
const CHANGECOUNT = 'changeCount';
const DELETE = 'delete';
const CHECKONE = 'checkone';
const ALLSELECT = 'allselect';
const GETSEARCHLIST = 'getsearchlist'

export {
  TAB_DATA,
  CAROU_IMG,
  HotNav,
  GOODLSIT,
  RECLIST,
  REWRITE,
  AUTOLOGIN,
  EDIT,
  CHANGECOUNT,
  DELETE,
  CHECKONE,
  ALLSELECT,
  GETSEARCHLIST
};