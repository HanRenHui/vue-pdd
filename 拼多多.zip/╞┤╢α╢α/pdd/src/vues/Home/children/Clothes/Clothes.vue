<template>
  <div class="clothes">
    女装
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'Clothes',
  data() {
    return {

    }
  },
  components: {

  }
}
</script>

<style scoped lang="stylus">
.clothes 
  line-height 20rem
</style>
