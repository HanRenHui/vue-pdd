<template>
  <div class="innerClothes">
    内衣模块
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'InnerClothes',
  data() {
    return {

    }
  },
  components: {

  }
}
</script>

<style scoped lang="stylus">
.innerClothes 
  line-height 20rem
</style>
